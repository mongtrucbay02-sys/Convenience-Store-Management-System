using ConvenienceStore.Web.Data;
using ConvenienceStore.Web.Modules.Auth.Models;
using ConvenienceStore.Web.Modules.Products.Services;
using ConvenienceStore.Web.Modules.Promotions.Services;
using ConvenienceStore.Web.Modules.Reports;
using ConvenienceStore.Web.Modules.Reports.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.Configure<Microsoft.AspNetCore.Mvc.Razor.RazorViewEngineOptions>(options =>
{
    options.AreaViewLocationFormats.Insert(0, "/Modules/{2}/Views/{1}/{0}.cshtml");
    options.AreaViewLocationFormats.Insert(1, "/Modules/{2}/Views/Shared/{0}.cshtml");
});

builder.Services.AddScoped<IProductService, ProductService>();
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddScoped<IDashboardDataSource, SampleDashboardDataSource>();
builder.Services.AddScoped<IDashboardService, DashboardService>();
builder.Services.AddSingleton<IPromotionDataSource>(sp =>
    new InMemoryPromotionDataSource(
        SamplePromotions.Create(sp.GetRequiredService<TimeProvider>().GetUtcNow())));
builder.Services.AddSingleton<IProductLookup, SampleProductLookup>();
builder.Services.AddScoped<IPromotionService, PromotionService>();

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException(
        "Missing DefaultConnection configuration. Set it with User Secrets or environment variables.");
builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseMySQL(connectionString));

builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    options.User.RequireUniqueEmail = true;
    options.Password.RequiredLength = 8;
    options.Password.RequireDigit = true;
    options.Password.RequireLowercase = true;
    options.Password.RequireUppercase = true;
    options.Password.RequireNonAlphanumeric = true;
    options.Lockout.AllowedForNewUsers = true;
    options.Lockout.MaxFailedAccessAttempts = 5;
    options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(10);
    options.SignIn.RequireConfirmedAccount = false; // Bài tập nhóm; cần bật xác nhận email khi triển khai thực tế.
})
.AddEntityFrameworkStores<ApplicationDbContext>()
.AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.Cookie.Name = "SmartMart.Auth";
    options.Cookie.HttpOnly = true;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
    options.SlidingExpiration = true;
    options.ExpireTimeSpan = TimeSpan.FromHours(8);
});

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy(AuthorizationPolicies.AdminOnly,
        policy => policy.RequireRole(AuthorizationPolicies.AdminRole));
    // Mặc định mọi MVC/API endpoint phải đăng nhập, trừ action có [AllowAnonymous].
    options.FallbackPolicy = new AuthorizationPolicyBuilder()
        .RequireAuthenticatedUser()
        .Build();
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.MapStaticAssets();
app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}");
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Dashboard}/{action=Index}/{id?}")
    .WithStaticAssets();

// Chạy sau khi đã tạo các bảng Identity bằng EF migration.
await SeedIdentityAsync(app);
app.Run();

static async Task SeedIdentityAsync(WebApplication app)
{
    using var scope = app.Services.CreateScope();
    var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
    var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
    var logger = scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("IdentitySeed");

    foreach (var role in new[] { AuthRoles.Admin, AuthRoles.Cashier })
    {
        if (!await roleManager.RoleExistsAsync(role))
        {
            var roleResult = await roleManager.CreateAsync(new IdentityRole(role));
            if (!roleResult.Succeeded)
                throw new InvalidOperationException("Không tạo được role: " +
                    string.Join("; ", roleResult.Errors.Select(e => e.Description)));
        }
    }

    // Không nhúng tài khoản/mật khẩu mặc định vào mã nguồn. Cấu hình qua User Secrets hoặc biến môi trường.
    var adminUserName = app.Configuration["Auth:BootstrapAdmin:UserName"];
    var adminEmail = app.Configuration["Auth:BootstrapAdmin:Email"];
    var adminPassword = app.Configuration["Auth:BootstrapAdmin:Password"];
    if (string.IsNullOrWhiteSpace(adminUserName) || string.IsNullOrWhiteSpace(adminEmail)
        || string.IsNullOrWhiteSpace(adminPassword))
    {
        logger.LogWarning("Chưa cấu hình tài khoản Admin khởi tạo. Hãy đặt Auth:BootstrapAdmin:UserName, Email và Password bằng User Secrets trước khi đăng nhập.");
        return;
    }

    var admin = await userManager.FindByNameAsync(adminUserName);
    if (admin is null)
    {
        admin = new ApplicationUser
        {
            UserName = adminUserName,
            Email = adminEmail,
            EmailConfirmed = true,
            FullName = "Quản trị viên",
            IsActive = true
        };
        var createResult = await userManager.CreateAsync(admin, adminPassword);
        if (!createResult.Succeeded)
            throw new InvalidOperationException("Không tạo được tài khoản Admin: " +
                string.Join("; ", createResult.Errors.Select(e => e.Description)));
    }

    if (!await userManager.IsInRoleAsync(admin, AuthRoles.Admin))
    {
        var roleResult = await userManager.AddToRoleAsync(admin, AuthRoles.Admin);
        if (!roleResult.Succeeded)
            throw new InvalidOperationException("Không gán được role Admin: " +
                string.Join("; ", roleResult.Errors.Select(e => e.Description)));
    }
}
