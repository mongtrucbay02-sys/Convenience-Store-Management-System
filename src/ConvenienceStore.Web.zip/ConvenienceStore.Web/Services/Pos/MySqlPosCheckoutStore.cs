﻿
using ConvenienceStore.Web.Data;
using ConvenienceStore.Web.Models.Pos;
using Microsoft.Extensions.Logging;
using MySqlConnector;

namespace ConvenienceStore.Web.Services.Pos;

public sealed class MySqlPosCheckoutStore : IPosCheckoutStore
{
    private readonly CuaHangDbContext _db;
    private readonly ILogger<MySqlPosCheckoutStore> _logger;

    public MySqlPosCheckoutStore(
        CuaHangDbContext db,
        ILogger<MySqlPosCheckoutStore> logger)
    {
        _db = db;
        _logger = logger;
    }

    public Task<long> SaveOrderAsync(
        MySqlConnection connection,
        MySqlTransaction transaction,
        PosCart cart,
        long cashReceived,
        long change,
        string cashierId,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();

        ArgumentNullException.ThrowIfNull(connection);
        ArgumentNullException.ThrowIfNull(transaction);
        ArgumentNullException.ThrowIfNull(cart);

        if (cart.Items == null || cart.Items.Count == 0)
        {
            throw new InvalidOperationException(
                "Giỏ hàng đang trống.");
        }

        if (cashReceived < 0 || change < 0)
        {
            throw new ArgumentOutOfRangeException(
                nameof(cashReceived),
                "Số tiền thanh toán không hợp lệ.");
        }

        if (string.IsNullOrWhiteSpace(cashierId))
        {
            throw new ArgumentException(
                "Không xác định được thu ngân.",
                nameof(cashierId));
        }

        _logger.LogInformation(
            "Bắt đầu lưu hóa đơn POS cho thu ngân {CashierId}",
            cashierId);

        // Chưa có schema MySQL thực tế để triển khai
        // lưu hóa đơn, chi tiết hóa đơn và trừ tồn kho.
        throw new NotImplementedException(
            "Chưa triển khai lưu hóa đơn theo database của nhóm.");
    }
}
