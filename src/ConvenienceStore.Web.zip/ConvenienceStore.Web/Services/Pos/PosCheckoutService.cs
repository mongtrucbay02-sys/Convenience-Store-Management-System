﻿
using System.Security.Claims;
using ConvenienceStore.Web.Models.Pos;
using MySqlConnector;

namespace ConvenienceStore.Web.Services.Pos;

// Kết quả hoàn tất đơn hàng POS-07
public sealed class PosCheckoutResult
{
    public bool Success { get; init; }

    public long? InvoiceId { get; init; }

    public string? ErrorMessage { get; init; }

    public long Total { get; init; }

    public long CashReceived { get; init; }

    public long Change { get; init; }
}

// Hợp đồng tích hợp CSDL hóa đơn và module Kho.
// Cần hiện thực theo schema đã duyệt của nhóm.
public interface IPosCheckoutStore
{
    Task<long> SaveOrderAsync(
        MySqlConnection connection,
        MySqlTransaction transaction,
        PosCart cart,
        long cashReceived,
        long change,
        string cashierId,
        CancellationToken cancellationToken);
}

public sealed class PosCheckoutService
{
    private readonly MySqlPosCatalog _catalog;
    private readonly IPosCheckoutStore _store;

    public PosCheckoutService(
        MySqlPosCatalog catalog,
        IPosCheckoutStore store)
    {
        _catalog = catalog;
        _store = store;
    }

    public async Task<PosCheckoutResult> CompleteAsync(
        PosCart cart,
        long cashReceived,
        ClaimsPrincipal user,
        CancellationToken cancellationToken = default)
    {
        // 1. Kiểm tra giỏ hàng
        if (cart == null ||
            cart.Items == null ||
            cart.Items.Count == 0)
        {
            return Failed("Giỏ hàng đang trống.");
        }

        if (cart.Items.Any(x =>
            x.ProductId <= 0 ||
            x.Quantity <= 0 ||
            x.UnitPrice < 0))
        {
            return Failed("Giỏ hàng có sản phẩm không hợp lệ.");
        }

        if (cart.Total <= 0)
        {
            return Failed("Tổng tiền phải lớn hơn 0.");
        }

        // 2. Kiểm tra thanh toán
        if (cashReceived < 0 ||
            cashReceived < cart.Total)
        {
            return Failed(
                "Khách chưa thanh toán đủ tiền.");
        }

        // 3. Kiểm tra tài khoản thu ngân
        if (user?.Identity?.IsAuthenticated != true)
        {
            return Failed("Thu ngân chưa đăng nhập.");
        }

        var cashierId =
            user.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        if (string.IsNullOrWhiteSpace(cashierId))
        {
            return Failed(
                "Không xác định được tài khoản thu ngân.");
        }

        // Đây chỉ là tính toán sơ bộ.
        // Store phải kiểm tra lại giá, tồn kho và
        // khuyến mãi trong transaction.
        long total = cart.Total;
        long change = cashReceived - total;

        // 4. Mở kết nối MySQL
        await using var connection =
            _catalog.CreateConnection();

        await connection.OpenAsync(cancellationToken);

        // 5. Bắt đầu transaction
        await using var transaction =
            await connection.BeginTransactionAsync(
                System.Data.IsolationLevel.ReadCommitted,
                cancellationToken);

        try
        {
            // 6. Store thực hiện trong transaction:
            // - Khóa và kiểm tra tồn kho
            // - Kiểm tra lại giá, khuyến mãi
            // - Lưu hóa đơn và chi tiết
            // - Lưu khoản thanh toán, tiền thừa
            // - Gọi dịch vụ kho BAN_HANG
            // - Ghi lượt sử dụng khuyến mãi
            //
            // Store phải trả về ID hóa đơn đã lưu.

            long invoiceId = await _store.SaveOrderAsync(
                connection,
                transaction,
                cart,
                cashReceived,
                change,
                cashierId,
                cancellationToken);

            if (invoiceId <= 0)
            {
                throw new InvalidOperationException(
                    "Không tạo được hóa đơn.");
            }

            // 7. Chỉ commit khi tất cả thành công
            await transaction.CommitAsync(
                cancellationToken);

            return new PosCheckoutResult
            {
                Success = true,
                InvoiceId = invoiceId,
                Total = total,
                CashReceived = cashReceived,
                Change = change
            };
        }
        catch
        {
            // 8. Rollback nếu có lỗi
            try
            {
                await transaction.RollbackAsync(
                    CancellationToken.None);
            }
            catch
            {
                // Có thể kết nối đã bị mất.
                // Cần kiểm tra trạng thái hóa đơn
                // trước khi thử lại giao dịch.
            }

            return Failed(
                "Không thể hoàn tất đơn hàng. " +
                "Vui lòng kiểm tra trạng thái hóa đơn " +
                "trước khi thử lại.");
        }
    }

    private static PosCheckoutResult Failed(string message)
    {
        return new PosCheckoutResult
        {
            Success = false,
            ErrorMessage = message
        };
    }
}
