$ErrorActionPreference = "Stop"

$project = Join-Path $PSScriptRoot "src/ConvenienceStore.Web/ConvenienceStore.Web.csproj"
if (-not (Test-Path $project)) {
    Write-Host "Khong tim thay project. Hay chay script tu thu muc goc cua goi code da giai nen." -ForegroundColor Red
    exit 1
}

Write-Host "Dang tao cau hinh tai khoan Admin cho Smart Mart..."
dotnet user-secrets set "Auth:BootstrapAdmin:UserName" "admin" --project $project
dotnet user-secrets set "Auth:BootstrapAdmin:Email" "admin@example.com" --project $project
dotnet user-secrets set "Auth:BootstrapAdmin:Password" "SmartMart@2026!" --project $project

if ($LASTEXITCODE -ne 0) {
    Write-Host "Khong the tao User Secrets. Hay cai .NET 10 SDK va thu lai." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Da luu cau hinh tai khoan Admin vao User Secrets tren may nay." -ForegroundColor Green
Write-Host "Ten dang nhap: admin"
Write-Host "Mat khau: SmartMart@2026!"
Write-Host ""
Write-Host "Luu y: Can cau hinh MySQL va chay migration/database update truoc khi dang nhap."
Write-Host "Khong commit mat khau nay len GitHub. Doi mat khau demo truoc khi dung that."
