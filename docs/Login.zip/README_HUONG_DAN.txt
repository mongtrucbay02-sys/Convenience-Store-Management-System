# SMART MART - CODE DANG NHAP (DA BO SUNG TAI KHOAN DEMO)

## Tai khoan demo
- Ten dang nhap: `admin`
- Mat khau: `SmartMart@2026!`

Tai khoan nay duoc cau hinh bang .NET User Secrets tren may chay ung dung, khong nhung mat khau vao ma nguon va khong day mat khau len GitHub.

## Cach tao tai khoan
1. Giai nen goi ZIP nay.
2. Mo PowerShell tai thu muc vua giai nen.
3. Chay lenh:
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\TAO_TAI_KHOAN_ADMIN.ps1
   ```
4. Cau hinh chuoi ket noi MySQL theo huong dan trong `docs/backend/auth-login-setup.md`.
5. Tao migration va cap nhat database theo huong dan.
6. Chay web bang HTTPS, mo `/Account/Login` va dang nhap bang tai khoan demo o tren.

## Luu y quan trong
- Day la goi code rieng cho chuc nang dang nhap, khong phai toan bo source GitHub.
- Tai khoan se duoc tao trong database khi ung dung khoi dong sau khi da co cau hinh User Secrets va cac bang Identity.
- Neu tai khoan `admin` da ton tai, code khong tu dong dat lai mat khau.
- Mat khau tren chi de test/demo. Hay doi mat khau rieng truoc khi su dung that.
- Khong upload file User Secrets hoac mat khau len GitHub.
- `Program.cs`, `ApplicationDbContext.cs`, `_AdminLayout.cshtml` va `.csproj` la cac file tich hop; doi chieu voi nhanh repo hien tai truoc khi ghi de.
- Code can duoc build va test tren may co .NET 10 va MySQL. Chua the xac nhan build trong goi nay.
