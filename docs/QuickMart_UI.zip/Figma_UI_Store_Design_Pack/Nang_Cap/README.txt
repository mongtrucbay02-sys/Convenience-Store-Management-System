BỘ GIAO DIỆN NÂNG CẤP QUICKMART
- Giữ nguyên bộ SVG ban đầu trong thư mục gốc.
- Thư mục Nang_Cap chứa các màn hình nâng cấp dạng SVG:
  01 Tổng quan, 02 Sản phẩm, 04 Khách hàng, 08 Báo cáo, 09 Đăng nhập,
  10 Lịch sử, 11 Giỏ hàng.
- File Excel đính kèm là bảng yêu cầu chức năng, danh sách màn hình và ghi chú triển khai.
CÁCH DÙNG: Giải nén ZIP, mở Figma Design, kéo từng SVG vào canvas.
LƯU Ý: Đây là mockup UI vector, không phải ứng dụng có backend. Các nút Google Login,
xuất Excel, thanh toán và thao tác CRUD cần được lập trình để hoạt động thực tế.
