using Microsoft.AspNetCore.Identity;

namespace ConvenienceStore.Web.Modules.Auth.Models;

/// <summary>Tài khoản đăng nhập của nhân viên Smart Mart.</summary>
public class ApplicationUser : IdentityUser
{
    public string FullName { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
}
