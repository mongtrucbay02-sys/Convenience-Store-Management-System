# AUTH - Đăng nhập Smart Mart

## Những gì đã thêm

- ASP.NET Core Identity dùng bảng tài khoản/role trong database hiện có qua `ApplicationDbContext`.
- Trang `/Account/Login` nhận username hoặc email, mật khẩu, tùy chọn ghi nhớ.
- Kiểm tra input phía server, thông báo lỗi chung, khóa đăng nhập tạm thời sau 5 lần sai (10 phút), chống CSRF cho POST.
- Cookie xác thực HttpOnly, Secure, SameSite=Lax; timeout 8 giờ.
- Fallback authorization: các controller/API endpoint yêu cầu đăng nhập trừ action được đánh dấu `[AllowAnonymous]`.
- Hai role được tạo: `Admin` và `Cashier`.
- Tài khoản Admin khởi tạo chỉ được tạo khi cấu hình thông tin qua User Secrets / biến môi trường; không có mật khẩu mặc định nhúng trong source.
- Form đăng xuất là POST và có antiforgery token.

## Điều kiện

Project dùng .NET 10, ASP.NET Core MVC/Razor và provider MySQL EF Core (`UseMySQL`). Cần có MySQL đang chạy và cấu hình `ConnectionStrings:DefaultConnection` đúng với môi trường của bạn.

## Chạy lần đầu

Mở terminal ở thư mục gốc repository. Cài .NET 10 SDK và công cụ EF nếu máy chưa có:

```bash
dotnet tool install --global dotnet-ef --version 10.0.13
```

Cấu hình chuỗi kết nối bằng User Secrets (thay các giá trị ví dụ bằng thông tin MySQL của nhóm):

```bash
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "server=localhost;port=3306;database=smart_mart;user=YOUR_DB_USER;password=YOUR_DB_PASSWORD;" --project src/ConvenienceStore.Web/ConvenienceStore.Web.csproj
```

Tạo tài khoản quản trị ban đầu bằng thông tin riêng của bạn. Hãy chọn mật khẩu mạnh, không commit mật khẩu vào GitHub:

```bash
dotnet user-secrets set "Auth:BootstrapAdmin:UserName" "admin" --project src/ConvenienceStore.Web/ConvenienceStore.Web.csproj
dotnet user-secrets set "Auth:BootstrapAdmin:Email" "admin@example.com" --project src/ConvenienceStore.Web/ConvenienceStore.Web.csproj
dotnet user-secrets set "Auth:BootstrapAdmin:Password" "REPLACE_WITH_A_STRONG_PASSWORD_123!" --project src/ConvenienceStore.Web/ConvenienceStore.Web.csproj
```

Tạo migration và cập nhật database (nếu nhóm đã có migration khác trên nhánh mới nhất, hãy kiểm tra/merge trước khi tạo migration để tránh trùng lặp):

```bash
dotnet ef migrations add AddIdentityAuthentication --project src/ConvenienceStore.Web/ConvenienceStore.Web.csproj --startup-project src/ConvenienceStore.Web/ConvenienceStore.Web.csproj
dotnet ef database update --project src/ConvenienceStore.Web/ConvenienceStore.Web.csproj --startup-project src/ConvenienceStore.Web/ConvenienceStore.Web.csproj
```

Chạy web bằng HTTPS:

```bash
dotnet run --project src/ConvenienceStore.Web/ConvenienceStore.Web.csproj --launch-profile https
```

Mở `https://localhost:7173/Account/Login` (chấp nhận chứng chỉ phát triển local nếu .NET yêu cầu). Đăng nhập bằng tài khoản đã cấu hình.

## Ghi chú trước khi đưa vào nhánh chung

1. Bản ZIP ban đầu không có migration hoặc schema tài khoản đã được xác nhận. Cần tạo migration, kiểm tra database và chạy thử trước khi merge.
2. Kiểm tra các controller/API đã có `[AllowAnonymous]` hoặc policy riêng; fallback policy nay yêu cầu đăng nhập cho mọi endpoint, trừ endpoint được cho phép công khai.
3. Role `Admin`/`Cashier` đã được tạo, nhưng chưa tự động gán mọi chức năng nghiệp vụ theo role. Hãy thêm `[Authorize(Roles = AuthRoles.Admin)]` hoặc policy tương ứng vào từng action khi nhóm chốt ma trận phân quyền.
4. Chức năng quên mật khẩu, xác minh email, MFA, tạo tài khoản nhân viên và quản trị tài khoản chưa được thêm vì repo chưa có cấu hình email và yêu cầu chính thức cho các luồng này.
5. Cookie được cấu hình `SecurePolicy.Always`, nên kiểm tra qua HTTPS, không qua URL HTTP thường.
6. Chưa thể chạy `dotnet build` hoặc test trong môi trường tạo gói này vì .NET SDK không có sẵn; cần build/test trên máy có .NET 10 và MySQL trước khi coi là hoàn tất.
