﻿
using System.Data;
using System.Data.Common;
using ConvenienceStore.Web.Data;
using ConvenienceStore.Web.Models.Pos;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace ConvenienceStore.Web.Services.Pos;

public sealed class MySqlPosInvoiceStore : IPosInvoiceStore
{
    private readonly CuaHangDbContext _db;
    private readonly ILogger<MySqlPosInvoiceStore> _logger;

    public MySqlPosInvoiceStore(
        CuaHangDbContext db,
        ILogger<MySqlPosInvoiceStore> logger)
    {
        _db = db;
        _logger = logger;
    }

    public async Task<PosInvoiceViewModel?> GetByIdAsync(
        long invoiceId,
        CancellationToken cancellationToken = default)
    {
        if (invoiceId <= 0)
            return null;

        try
        {
            var connection = _db.Database.GetDbConnection();

            var shouldClose =
                connection.State != ConnectionState.Open;

            if (shouldClose)
                await connection.OpenAsync(cancellationToken);

            try
            {
                // 1. Đọc thông tin hóa đơn
                await using var command =
                    connection.CreateCommand();

                command.CommandText = """
                    SELECT
                        h.id,
                        h.ma_hoa_don,
                        h.ngay_tao,
                        h.ten_thu_ngan,
                        h.ten_khach_hang,
                        h.trang_thai,
                        h.tam_tinh,
                        h.giam_gia,
                        h.tong_tien,
                        h.tien_khach_dua,
                        h.tien_thua
                    FROM hoa_don h
                    WHERE h.id = @invoiceId
                    LIMIT 1;
                    """;

                AddParameter(
                    command, "@invoiceId", invoiceId);

                PosInvoiceViewModel? invoice = null;

                await using (var reader =
                    await command.ExecuteReaderAsync(
                        cancellationToken))
                {
                    if (!await reader.ReadAsync(
                            cancellationToken))
                    {
                        return null;
                    }

                    invoice = new PosInvoiceViewModel
                    {
                        InvoiceId = GetLong(reader, "id"),
                        InvoiceCode =
                            GetString(reader, "ma_hoa_don"),

                        CreatedAt =
                            GetDateTime(reader, "ngay_tao"),

                        CashierName =
                            GetString(reader, "ten_thu_ngan"),

                        CustomerName =
                            GetNullableString(
                                reader, "ten_khach_hang"),

                        Status =
                            GetString(reader, "trang_thai"),

                        Subtotal =
                            GetLong(reader, "tam_tinh"),

                        Discount =
                            GetLong(reader, "giam_gia"),

                        Total =
                            GetLong(reader, "tong_tien"),

                        CashReceived =
                            GetLong(reader, "tien_khach_dua"),

                        Change =
                            GetLong(reader, "tien_thua")
                    };
                }

                // 2. Đọc chi tiết hóa đơn
                await using var itemCommand =
                    connection.CreateCommand();

                itemCommand.CommandText = """
                    SELECT
                        ct.ten_san_pham,
                        ct.so_luong,
                        ct.don_gia,
                        ct.giam_gia,
                        ct.thanh_tien
                    FROM chi_tiet_hoa_don ct
                    WHERE ct.hoa_don_id = @invoiceId
                    ORDER BY ct.id;
                    """;

                AddParameter(
                    itemCommand, "@invoiceId", invoiceId);

                await using (var reader =
                    await itemCommand.ExecuteReaderAsync(
                        cancellationToken))
                {
                    while (await reader.ReadAsync(
                               cancellationToken))
                    {
                        invoice.Items.Add(
                            new PosInvoiceItemViewModel
                            {
                                ProductName =
                                    GetString(
                                        reader, "ten_san_pham"),

                                Quantity =
                                    checked((int)GetLong(
                                        reader, "so_luong")),

                                UnitPrice =
                                    GetLong(reader, "don_gia"),

                                Discount =
                                    GetLong(reader, "giam_gia"),

                                LineTotal =
                                    GetLong(reader, "thanh_tien")
                            });
                    }
                }

                return invoice;
            }
            finally
            {
                if (shouldClose)
                    await connection.CloseAsync();
            }
        }
        catch (OperationCanceledException)
            when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "Không thể đọc hóa đơn POS {InvoiceId}",
                invoiceId);

            throw;
        }
    }

    private static void AddParameter(
        DbCommand command,
        string name,
        object value)
    {
        var parameter = command.CreateParameter();
        parameter.ParameterName = name;
        parameter.Value = value;
        command.Parameters.Add(parameter);
    }

    private static string GetString(
        DbDataReader reader,
        string column)
    {
        var index = reader.GetOrdinal(column);

        return reader.IsDBNull(index)
            ? ""
            : Convert.ToString(reader.GetValue(index)) ?? "";
    }

    private static string? GetNullableString(
        DbDataReader reader,
        string column)
    {
        var index = reader.GetOrdinal(column);

        return reader.IsDBNull(index)
            ? null
            : Convert.ToString(reader.GetValue(index));
    }

    private static long GetLong(
        DbDataReader reader,
        string column)
    {
        var index = reader.GetOrdinal(column);

        return reader.IsDBNull(index)
            ? 0
            : Convert.ToInt64(reader.GetValue(index));
    }

    private static DateTime GetDateTime(
        DbDataReader reader,
        string column)
    {
        var index = reader.GetOrdinal(column);

        return reader.IsDBNull(index)
            ? DateTime.MinValue
            : Convert.ToDateTime(reader.GetValue(index));
    }
}
