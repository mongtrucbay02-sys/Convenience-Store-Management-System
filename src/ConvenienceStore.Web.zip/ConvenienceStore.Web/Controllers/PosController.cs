﻿
using System.Globalization;
using ConvenienceStore.Web.Models.Pos;
using ConvenienceStore.Web.Modules.Auth.Security;
using ConvenienceStore.Web.Services.Pos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ConvenienceStore.Web.Controllers;

[Authorize(Policy = MaQuyen.BanHang)]
public sealed class PosController : Controller
{
    private readonly MySqlPosCatalog _catalog;
    private readonly PosCartService _cart;
    private readonly PosPaymentService _posPayment;
    private readonly PosCheckoutService _checkoutService;
    private readonly PosInvoiceService _invoiceService;

    // ==========================================
    // CONSTRUCTOR - DEPENDENCY INJECTION
    // ==========================================

    public PosController(
        MySqlPosCatalog catalog,
        PosCartService cart,
        PosPaymentService posPayment,
        PosCheckoutService checkoutService,
        PosInvoiceService invoiceService)
    {
        _catalog = catalog;
        _cart = cart;
        _posPayment = posPayment;
        _checkoutService = checkoutService;
        _invoiceService = invoiceService;
    }

    // ==========================================
    // POS-01: HIỂN THỊ SẢN PHẨM VÀ GIỎ HÀNG
    // ==========================================

    [HttpGet]
    public async Task<IActionResult> Index(
        string? search,
        int? categoryId)
    {
        if (categoryId.HasValue && categoryId.Value <= 0)
        {
            categoryId = null;
        }

        var model = new PosPageViewModel
        {
            Products = await _catalog.SearchAsync(
                search, categoryId),

            Categories = await _catalog.GetCategoriesAsync(),

            CategoryId = categoryId,
            Cart = await _cart.GetCartAsync(),
            Search = search ?? ""
        };

        return View(model);
    }

    // ==========================================
    // POS-01: THÊM SẢN PHẨM
    // ==========================================

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Add(int productId)
    {
        if (productId <= 0)
        {
            TempData["Error"] = "Sản phẩm không hợp lệ.";
            return RedirectToAction(nameof(Index));
        }

        var error = await _cart.AddAsync(productId);

        TempData[error == null ? "Success" : "Error"] =
            error ?? "Đã thêm sản phẩm vào giỏ.";

        return RedirectToAction(nameof(Index));
    }

    // ==========================================
    // POS-02: CẬP NHẬT SỐ LƯỢNG
    // ==========================================

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Update(
        int productId,
        string? quantity)
    {
        if (productId <= 0)
        {
            TempData["Error"] = "Sản phẩm không hợp lệ.";
            return RedirectToAction(nameof(Index));
        }

        if (!int.TryParse(
                quantity,
                NumberStyles.None,
                CultureInfo.InvariantCulture,
                out int newQuantity))
        {
            TempData["Error"] =
                "Số lượng phải là số nguyên không âm.";

            return RedirectToAction(nameof(Index));
        }

        var error = await _cart.UpdateAsync(
            productId, newQuantity);

        if (error != null)
        {
            TempData["Error"] = error;
        }
        else
        {
            TempData["Success"] = newQuantity == 0
                ? "Đã xóa sản phẩm khỏi giỏ."
                : "Đã cập nhật số lượng sản phẩm.";
        }

        return RedirectToAction(nameof(Index));
    }

    // ==========================================
    // POS-02: XÓA SẢN PHẨM
    // ==========================================

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Remove(int productId)
    {
        if (productId <= 0)
        {
            TempData["Error"] = "Sản phẩm không hợp lệ.";
            return RedirectToAction(nameof(Index));
        }

        var error = await _cart.UpdateAsync(productId, 0);

        TempData[error == null ? "Success" : "Error"] =
            error ?? "Đã xóa sản phẩm khỏi giỏ.";

        return RedirectToAction(nameof(Index));
    }

    // ==========================================
    // TÍNH TIỀN KHÁCH ĐƯA
    // ==========================================

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Calculate(
        long cashReceived)
    {
        var cart = await _cart.GetCartAsync();

        var error = await _cart.ValidateCartAsync(cart);

        if (error != null)
        {
            TempData["Error"] = error;
            return RedirectToAction(nameof(Index));
        }

        if (cashReceived < 0)
        {
            TempData["Error"] =
                "Tiền khách đưa không được âm.";

            return RedirectToAction(nameof(Index));
        }

        if (cashReceived < cart.Total)
        {
            TempData["Error"] =
                $"Khách đưa chưa đủ. Cần thêm " +
                $"{cart.Total - cashReceived:N0} đ.";

            return RedirectToAction(nameof(Index));
        }

        var model = new PosPageViewModel
        {
            Products = await _catalog.SearchAsync(null),
            Categories = await _catalog.GetCategoriesAsync(),
            Cart = cart,
            CashReceived = cashReceived,
            Change = cashReceived - cart.Total
        };

        return View("Index", model);
    }

    // ==========================================
    // POS-05: TRANG CHỌN THANH TOÁN
    // ==========================================

    [HttpGet]
    public async Task<IActionResult> Checkout()
    {
        var cart = await _cart.GetCartAsync();

        var error = await _cart.ValidateCartAsync(cart);

        if (error != null)
        {
            TempData["Error"] = error;
            return RedirectToAction(nameof(Index));
        }

        var model = new PosCheckoutViewModel
        {
            Subtotal = cart.Subtotal,
            Discount = cart.Discount,
            Total = cart.Total
        };

        return View("Checkout", model);
    }

    // ==========================================
    // POS-05: TRANG THANH TOÁN TIỀN MẶT
    // ==========================================

    [HttpGet]
    public async Task<IActionResult> Cash()
    {
        var cart = await _cart.GetCartAsync();

        var error = await _cart.ValidateCartAsync(cart);

        if (error != null)
        {
            TempData["Error"] = error;
            return RedirectToAction(nameof(Index));
        }

        var model = new PosCheckoutViewModel
        {
            Subtotal = cart.Subtotal,
            Discount = cart.Discount,
            Total = cart.Total
        };

        return View("Cash", model);
    }

    // ==========================================
    // POS-05: XÁC NHẬN TIỀN KHÁCH ĐƯA
    // ==========================================

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ConfirmCash(
        string? cashReceived)
    {
        var cart = await _cart.GetCartAsync();

        var error = await _cart.ValidateCartAsync(cart);

        if (error != null)
        {
            TempData["Error"] = error;
            return RedirectToAction(nameof(Index));
        }

        var model = new PosCheckoutViewModel
        {
            Subtotal = cart.Subtotal,
            Discount = cart.Discount,
            Total = cart.Total,
            CashInput = cashReceived ?? ""
        };

        if (!long.TryParse(
                cashReceived,
                NumberStyles.None,
                CultureInfo.InvariantCulture,
                out long cash))
        {
            model.Error =
                "Tiền khách đưa không hợp lệ.";

            return View("Cash", model);
        }

        model.CashReceived = cash;

        if (cash < cart.Total)
        {
            model.Error =
                $"Khách đưa chưa đủ. Còn thiếu " +
                $"{cart.Total - cash:N0} đ.";

            return View("Cash", model);
        }

        model.Change = cash - cart.Total;

        // POS-05 chỉ chuẩn bị thanh toán.
        // Chưa lưu hóa đơn và chưa trừ kho.
        model.Message = await _posPayment.PrepareAsync(
            cart,
            cash,
            model.Change.Value);

        return View("Cash", model);
    }

    // ==========================================
    // POS-07: HOÀN TẤT ĐƠN HÀNG
    // ==========================================

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CompleteOrder(
        string? cashReceived,
        CancellationToken cancellationToken)
    {
        // 1. Lấy giỏ hàng
        var cart = await _cart.GetCartAsync();

        // 2. Kiểm tra giỏ hàng
        var cartError =
            await _cart.ValidateCartAsync(cart);

        if (cartError != null)
        {
            TempData["Error"] = cartError;
            return RedirectToAction(nameof(Index));
        }

        // 3. Kiểm tra tiền khách đưa
        if (!long.TryParse(
                cashReceived,
                NumberStyles.None,
                CultureInfo.InvariantCulture,
                out long cash))
        {
            TempData["Error"] =
                "Tiền khách đưa không hợp lệ.";

            return RedirectToAction(nameof(Cash));
        }

        if (cash < cart.Total)
        {
            TempData["Error"] =
                $"Khách thanh toán chưa đủ. " +
                $"Còn thiếu {cart.Total - cash:N0} đ.";

            return RedirectToAction(nameof(Cash));
        }

        // 4. Gọi service hoàn tất đơn
        PosCheckoutResult result;

        try
        {
            result = await _checkoutService.CompleteAsync(
                cart,
                cash,
                User,
                cancellationToken);
        }
        catch (OperationCanceledException)
            when (cancellationToken.IsCancellationRequested)
        {
            TempData["Error"] =
                "Yêu cầu bị gián đoạn. " +
                "Hãy kiểm tra hóa đơn trước khi thử lại.";

            return RedirectToAction(nameof(Cash));
        }
        catch (Exception)
        {
            TempData["Error"] =
                "Không thể xác định trạng thái thanh toán. " +
                "Hãy kiểm tra hóa đơn trước khi thử lại.";

            return RedirectToAction(nameof(Cash));
        }

        // 5. Kiểm tra kết quả
        if (!result.Success ||
            result.InvoiceId is null ||
            result.InvoiceId <= 0)
        {
            TempData["Error"] =
                result.ErrorMessage ??
                "Không thể hoàn tất đơn hàng.";

            return RedirectToAction(nameof(Cash));
        }

        // 6. Xóa giỏ sau khi giao dịch đã commit
        try
        {
            await _cart.CancelAsync();
        }
        catch (Exception)
        {
            TempData["Error"] =
                $"Hóa đơn {result.InvoiceId} đã lưu, " +
                "nhưng chưa thể làm trống giỏ hàng. " +
                "Không thanh toán lại đơn này.";

            // Vẫn chuyển sang hóa đơn đã lưu.
            return RedirectToAction(
                nameof(Receipt),
                new { invoiceId = result.InvoiceId.Value });
        }

        // 7. Thông báo thành công
        TempData["Success"] =
            $"Thanh toán thành công. " +
            $"Mã hóa đơn: {result.InvoiceId}. " +
            $"Tiền thừa: {result.Change:N0} đ.";

        // 8. Chuyển sang trang hóa đơn K80
        return RedirectToAction(
            nameof(Receipt),
            new { invoiceId = result.InvoiceId.Value });
    }

    // ==========================================
    // POS-07: XEM VÀ IN HÓA ĐƠN K80
    // ==========================================

    [HttpGet]
    public async Task<IActionResult> Receipt(
        long invoiceId,
        CancellationToken cancellationToken)
    {
        if (invoiceId <= 0)
        {
            return BadRequest(
                "Mã hóa đơn không hợp lệ.");
        }

        // Đọc hóa đơn đã lưu từ database
        var invoice = await _invoiceService.GetByIdAsync(
            invoiceId,
            cancellationToken);

        if (invoice == null)
        {
            return NotFound(
                "Không tìm thấy hóa đơn đã thanh toán.");
        }

        // Kiểm tra dữ liệu trước khi in
        if (!_invoiceService.ValidateForPrinting(
                invoice,
                out var error))
        {
            return BadRequest(error);
        }

        // TODO: Kiểm tra quyền truy cập hóa đơn
        // theo cửa hàng/ca bán nếu hệ thống
        // phân tách dữ liệu giữa các thu ngân.

        return View("Receipt", invoice);
    }

    // ==========================================
    // POS-09: HỦY ĐƠN ĐANG BÁN
    // ==========================================

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancel()
    {
        await _cart.CancelAsync();

        TempData["Success"] =
            "Đã hủy đơn hàng đang bán.";

        return RedirectToAction(nameof(Index));
    }
}
