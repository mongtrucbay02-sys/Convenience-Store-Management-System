namespace ConvenienceStore.Web.Modules.Auth.Models;

public static class AuthRoles
{
    public const string Admin = "Admin";
    public const string Cashier = "Cashier";
}
